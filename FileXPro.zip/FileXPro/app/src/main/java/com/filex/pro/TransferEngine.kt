package com.filex.pro

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.HttpURLConnection
import java.net.NetworkInterface
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom

data class PickedFile(val uri: Uri, val name: String, val size: Long, val mime: String)

data class TransferState(
    val active: Boolean = false,
    val done: Boolean = false,
    val error: String? = null,
    val totalBytes: Long = 0,
    val doneBytes: Long = 0,
    val speedBps: Double = 0.0,
    val currentFile: String = "",
    val verified: Int = 0,
    val mismatched: Int = 0,
    val fileCount: Int = 0
) {
    val percent: Float
        get() = if (totalBytes > 0) (doneBytes.toDouble() / totalBytes).toFloat().coerceIn(0f, 1f) else 0f
    val remainingSec: Long
        get() = if (speedBps > 1) ((totalBytes - doneBytes) / speedBps).toLong() else -1L
}

data class HistoryItem(val time: Long, val dir: String, val count: Int, val bytes: Long, val ok: Boolean)

/** حساب السرعة المتوسطة */
class Meter {
    private var start = 0L
    fun speed(done: Long): Double {
        if (start == 0L) start = System.nanoTime()
        val s = (System.nanoTime() - start) / 1e9
        return if (s > 0.3) done / s else 0.0
    }
}

class CountingInputStream(ins: InputStream, private val cb: (Long) -> Unit) : FilterInputStream(ins) {
    override fun read(): Int {
        val r = super.read()
        if (r >= 0) cb(1)
        return r
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) cb(n.toLong())
        return n
    }
}

class SenderServer(
    private val ctx: Context,
    private val files: List<PickedFile>,
    private val hashes: List<String>,
    private val token: String,
    port: Int,
    private val onBytes: (Long) -> Unit
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        if (session.parms["t"] != token) {
            return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "forbidden")
        }
        val path = session.uri
        return try {
            when {
                path == "/list" -> {
                    val arr = JSONArray()
                    files.forEachIndexed { i, f ->
                        arr.put(
                            JSONObject().put("name", f.name).put("size", f.size)
                                .put("mime", f.mime).put("sha256", hashes[i])
                        )
                    }
                    newFixedLengthResponse(Response.Status.OK, "application/json", arr.toString())
                }
                path.startsWith("/file/") -> {
                    val idx = path.removePrefix("/file/").toIntOrNull() ?: -1
                    val f = files.getOrNull(idx)
                        ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found")
                    val raw = ctx.contentResolver.openInputStream(f.uri) ?: throw IOException("open failed")
                    newFixedLengthResponse(
                        Response.Status.OK, "application/octet-stream",
                        CountingInputStream(raw, onBytes), f.size
                    )
                }
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", e.message ?: "error")
        }
    }
}

object Engine {
    const val PORT = 8765

    val sendState = MutableStateFlow(TransferState())
    val recvState = MutableStateFlow(TransferState())
    val qr = MutableStateFlow<String?>(null)

    private var server: SenderServer? = null

    @Volatile private var gen = 0
    @Volatile private var recvCancel = false

    // ---------- أدوات ----------
    fun queryFile(ctx: Context, uri: Uri): PickedFile {
        var name = "file"
        var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        if (size < 0) {
            size = try {
                ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
            } catch (e: Exception) { 0L }
            if (size < 0) size = 0
        }
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        return PickedFile(uri, name, size, mime)
    }

    fun sha256(ctx: Context, uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val r = ins.read(buf)
                if (r < 0) break
                md.update(buf, 0, r)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun localIp(): String? {
        val cands = mutableListOf<Pair<String, String>>()
        NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
            if (!ni.isUp || ni.isLoopback) return@forEach
            ni.inetAddresses.toList().forEach { a ->
                if (a is Inet4Address && a.isSiteLocalAddress) cands.add(ni.name to a.hostAddress!!)
            }
        }
        return cands.firstOrNull {
            it.first.startsWith("wlan") || it.first.startsWith("ap") ||
                it.first.startsWith("swlan") || it.first.startsWith("eth")
        }?.second
    }

    private fun randomToken(): String {
        val b = ByteArray(12)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    // ---------- المرسل ----------
    fun stopSending() {
        gen++
        server?.stop()
        server = null
    }

    fun startSending(ctx: Context, files: List<PickedFile>) {
        stopSending()
        val my = gen
        qr.value = null
        val total = files.sumOf { it.size }
        sendState.value = TransferState(totalBytes = total, fileCount = files.size)
        Thread {
            try {
                val hashes = files.map { sha256(ctx, it.uri) }
                if (my != gen) return@Thread
                val ip = localIp() ?: throw IOException(
                    "ما لقيناش شبكة Wi-Fi. وصّل الهاتفين بنفس الـ Wi-Fi أو فعّل نقطة الاتصال (Hotspot)."
                )
                val token = randomToken()
                val meter = Meter()
                val lock = Any()
                var sent = 0L
                val s = SenderServer(ctx, files, hashes, token, PORT) { n ->
                    synchronized(lock) {
                        sent += n
                        val d = sent.coerceAtMost(total)
                        val finished = total > 0 && d >= total
                        val was = sendState.value.done
                        sendState.value = sendState.value.copy(
                            active = !finished, done = finished,
                            doneBytes = d, speedBps = meter.speed(d)
                        )
                        if (finished && !was) addHistory(ctx, "sent", files.size, total, true)
                    }
                }
                s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                if (my != gen) { s.stop(); return@Thread }
                server = s
                qr.value = "http://$ip:$PORT/?t=$token"
            } catch (e: Exception) {
                sendState.value = sendState.value.copy(error = e.message ?: "خطأ")
            }
        }.start()
    }

    // ---------- المستقبل ----------
    fun resetRecv() {
        recvCancel = true
        recvState.value = TransferState()
    }

    fun cancelRecv() {
        recvCancel = true
    }

    private fun httpText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 30000
        if (c.responseCode != 200) throw IOException("رفض السيرفر الاتصال (${c.responseCode})")
        return c.inputStream.bufferedReader().use { it.readText() }
    }


    private class Sink(val out: OutputStream, val commit: () -> Unit, val discard: () -> Unit)

    /** أندرويد 10+: MediaStore ، أندرويد 9 وأقل: مجلد Download/FileX مباشرة */
    private fun openSink(ctx: Context, name: String, mime: String): Sink {
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FileX")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val dst = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("تعذر إنشاء الملف")
            val out = resolver.openOutputStream(dst) ?: throw IOException("تعذر فتح الملف")
            return Sink(
                out,
                { resolver.update(dst, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null) },
                { resolver.delete(dst, null, null) }
            )
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "FileX")
        dir.mkdirs()
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var f = File(dir, name)
        var k = 1
        while (f.exists()) { f = File(dir, "$base ($k)$ext"); k++ }
        val target = f
        return Sink(
            FileOutputStream(target),
            { MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), null, null) },
            { target.delete() }
        )
    }

    private fun safeName(n: String) = n.replace("/", "_").replace("\\", "_")

    fun receive(ctx: Context, url: String) {
        recvCancel = false
        recvState.value = TransferState(active = true, currentFile = "جاري الاتصال...")
        Thread {
            try {
                val u = Uri.parse(url)
                if (u.scheme != "http") throw IOException("رمز QR غير صالح")
                val token = u.getQueryParameter("t") ?: throw IOException("رمز QR غير صالح")
                val base = "http://${u.authority}"
                val arr = JSONArray(httpText("$base/list?t=$token"))
                val n = arr.length()
                var total = 0L
                for (i in 0 until n) total += arr.getJSONObject(i).getLong("size")
                recvState.value = TransferState(active = true, totalBytes = total, fileCount = n)

                val meter = Meter()
                var done = 0L
                var ok = 0
                var bad = 0
                val resolver = ctx.contentResolver

                for (i in 0 until n) {
                    val o = arr.getJSONObject(i)
                    val name = safeName(o.getString("name"))
                    var mime = o.optString("mime", "application/octet-stream")
                    if (mime == "application/octet-stream") {
                        val ext = name.substringAfterLast('.', "").lowercase()
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { mime = it }
                    }
                    recvState.value = recvState.value.copy(currentFile = name)

                    val conn = URL("$base/file/$i?t=$token").openConnection() as HttpURLConnection
                    conn.connectTimeout = 10000
                    conn.readTimeout = 30000
                    val md = MessageDigest.getInstance("SHA-256")
                    val sink = openSink(ctx, name, mime)
                    try {
                        conn.inputStream.use { input ->
                            sink.out.use { out ->
                                val buf = ByteArray(256 * 1024)
                                while (true) {
                                    if (recvCancel) throw IOException("تم إيقاف النقل")
                                    val r = input.read(buf)
                                    if (r < 0) break
                                    out.write(buf, 0, r)
                                    md.update(buf, 0, r)
                                    done += r
                                    recvState.value = recvState.value.copy(
                                        doneBytes = done, speedBps = meter.speed(done)
                                    )
                                }
                            }
                        }
                    } catch (e: Exception) {
                        sink.discard()
                        throw e
                    }
                    val hash = md.digest().joinToString("") { "%02x".format(it) }
                    if (hash.equals(o.getString("sha256"), ignoreCase = true)) {
                        ok++
                        sink.commit()
                    } else {
                        bad++
                        sink.discard()
                    }
                    recvState.value = recvState.value.copy(verified = ok, mismatched = bad)
                }
                recvState.value = recvState.value.copy(active = false, done = true, doneBytes = total)
                addHistory(ctx, "received", n, total, bad == 0)
            } catch (e: Exception) {
                recvState.value = recvState.value.copy(active = false, error = e.message ?: "خطأ في الاتصال")
            }
        }.start()
    }

    // ---------- السجل ----------
    fun addHistory(ctx: Context, dir: String, count: Int, bytes: Long, ok: Boolean) {
        val p = ctx.getSharedPreferences("filex", Context.MODE_PRIVATE)
        val old = JSONArray(p.getString("h", "[]"))
        val out = JSONArray()
        out.put(JSONObject().put("t", System.currentTimeMillis()).put("d", dir).put("c", count).put("b", bytes).put("ok", ok))
        for (i in 0 until minOf(old.length(), 99)) out.put(old.get(i))
        p.edit().putString("h", out.toString()).apply()
    }

    fun history(ctx: Context): List<HistoryItem> {
        val p = ctx.getSharedPreferences("filex", Context.MODE_PRIVATE)
        val a = JSONArray(p.getString("h", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(o.getLong("t"), o.getString("d"), o.getInt("c"), o.getLong("b"), o.getBoolean("ok"))
        }
    }
}
