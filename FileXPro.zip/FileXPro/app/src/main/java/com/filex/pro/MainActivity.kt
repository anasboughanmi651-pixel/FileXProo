package com.filex.pro

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val BgDark = Color(0xFF050A1E)
val Blue = Color(0xFF2979FF)
val Violet = Color(0xFF7C4DFF)
val CardDark = Color(0xFF0D1636)

enum class Screen { Splash, Main, Pick, Send, Receive }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = BgDark, surface = CardDark, primary = Blue)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

// ---------- أدوات عرض ----------
fun fmtSize(b: Long): String = when {
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    b >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

fun fmtTime(s: Long): String =
    if (s < 0) "--:--:--" else String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)

fun qrBitmap(text: String, size: Int = 720): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
    val black = 0xFF000000.toInt()
    val white = 0xFFFFFFFF.toInt()
    for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (m[x, y]) black else white)
    return bmp
}

@Composable
fun Crown() = Text("👑", fontSize = 28.sp)

@Composable
fun Signature() = Text(
    "By : Adem Hadyaoui", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp,
    modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center
)

// ---------- التطبيق ----------
@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.Splash) }
    var tab by remember { mutableIntStateOf(0) }
    val picked = remember { mutableStateListOf<PickedFile>() }

    BackHandler(enabled = screen != Screen.Main && screen != Screen.Splash) {
        screen = Screen.Main
    }

    Box(Modifier.fillMaxSize().background(BgDark)) {
        when (screen) {
            Screen.Splash -> SplashScreen { screen = Screen.Main }
            Screen.Main -> MainScreen(
                onSend = { tab = 0; screen = Screen.Pick },
                onReceive = { screen = Screen.Receive },
                onTool = { t -> tab = t; screen = Screen.Pick }
            )
            Screen.Pick -> PickScreen(tab, { tab = it }, picked, { screen = Screen.Main }, { screen = Screen.Send })
            Screen.Send -> SendScreen(picked.toList()) { picked.clear(); screen = Screen.Main }
            Screen.Receive -> ReceiveScreen { screen = Screen.Main }
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(1800); onDone() }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Image(painterResource(R.drawable.filex_icon), null, Modifier.size(140.dp).clip(RoundedCornerShape(32.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(16.dp))
        Crown()
        Text("FileX Pro", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
        Text("أسرع طريقة لنقل ملفاتك", color = Color.White.copy(alpha = 0.8f))
        Spacer(Modifier.height(24.dp))
        LinearProgressIndicator(Modifier.width(180.dp), color = Blue)
        Spacer(Modifier.height(24.dp))
        Signature()
    }
}

@Composable
fun BigButton(title: String, sub: String, c1: Color, c2: Color, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp).height(110.dp)
            .clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(c1, c2)))
            .clickable { onClick() }.padding(20.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

@Composable
fun MainScreen(onSend: () -> Unit, onReceive: () -> Unit, onTool: (Int) -> Unit) {
    val ctx = LocalContext.current
    var nav by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (nav) {
                0 -> Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Crown(); Spacer(Modifier.width(6.dp))
                        Text("FileX Pro", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    BigButton("إرسال الملفات", "شاركها بسهولة", Blue, Color(0xFF1E88E5), onSend)
                    BigButton("تلقي الملفات", "استقبل الملفات من الآخرين", Violet, Color(0xFF9C27B0), onReceive)
                    Text("أدوات إضافية", color = Color.White, modifier = Modifier.padding(20.dp), fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        val tools = listOf<Pair<String, () -> Unit>>(
                            "نقل التطبيقات" to { onTool(3) },
                            "نقل الصور والفيديو" to { onTool(0) },
                            "نقل الملفات الكبيرة" to { onTool(1) }
                        )
                        tools.forEach { (label, act) ->
                            Box(
                                Modifier.weight(1f).height(90.dp).clip(RoundedCornerShape(18.dp)).background(CardDark).clickable { act() },
                                contentAlignment = Alignment.Center
                            ) { Text(label, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center) }
                        }
                    }
                }
                1 -> HistoryScreen()
                else -> SettingsScreen()
            }
        }
        Row(Modifier.fillMaxWidth().background(CardDark).padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("الرئيسية", "السجل", "الإعدادات").forEachIndexed { i, t ->
                Text(
                    t, color = if (nav == i) Blue else Color.White.copy(alpha = 0.6f),
                    fontWeight = if (nav == i) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clickable { nav = i }.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }
        Signature()
    }
}

@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    val items = remember { Engine.history(ctx) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("سجل التحويلات", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) Text("ما فما حتى عملية نقل بعد.", color = Color.White.copy(alpha = 0.6f))
        LazyColumn {
            items(items) { h ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(CardDark).padding(14.dp)) {
                    Text(
                        (if (h.dir == "sent") "📤 إرسال" else "📥 استقبال") + "  ·  ${h.count} ملف  ·  ${fmtSize(h.bytes)}",
                        color = Color.White
                    )
                    Text(
                        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(h.time)) +
                            if (h.ok) "  ✓ تم التحقق" else "  ⚠ فيه ملفات ما تطابقتش",
                        color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Image(painterResource(R.drawable.filex_icon), null, Modifier.size(100.dp).clip(RoundedCornerShape(24.dp)))
        Crown()
        Text("FileX Pro", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("الإصدار 1.0", color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.height(16.dp))
        Text(
            "الملفات تتحفظ في Download/FileX\nالنقل عبر Wi-Fi محلي بدون إنترنت\nالتحقق من كل ملف بـ SHA-256",
            color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center
        )
    }
}

@Composable
fun PickScreen(tab: Int, onTab: (Int) -> Unit, picked: MutableList<PickedFile>, onBack: () -> Unit, onSend: () -> Unit) {
    val ctx = LocalContext.current
    val tabs = listOf("الصور", "الملفات", "الفيديوهات", "التطبيقات")
    val mimes = listOf(
        arrayOf("image/*"), arrayOf("*/*"), arrayOf("video/*"),
        arrayOf("application/vnd.android.package-archive")
    )
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u -> if (picked.none { it.uri == u }) picked.add(Engine.queryFile(ctx, u)) }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("اختر الملفات للإرسال", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.forEachIndexed { i, t ->
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (i == tab) Blue else CardDark)
                        .clickable { onTab(i) }.padding(12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(t, color = Color.White, fontSize = 12.sp) }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { launcher.launch(mimes[tab]) }, Modifier.fillMaxWidth()) { Text("اختيار من: ${tabs[tab]}") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(picked) { f ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(CardDark).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, color = Color.White, maxLines = 1, fontSize = 14.sp)
                        Text(fmtSize(f.size), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    }
                    Text("✕", color = Color.White, modifier = Modifier.clickable { picked.remove(f) }.padding(8.dp))
                }
            }
        }
        Text("تم تحديد ${picked.size} ملفات · ${fmtSize(picked.sumOf { it.size })}", color = Color.White, modifier = Modifier.padding(vertical = 8.dp))
        Button(
            onClick = onSend, enabled = picked.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)
        ) { Text("إرسال الآن") }
        TextButton(onClick = onBack, Modifier.fillMaxWidth()) { Text("رجوع") }
        Signature()
    }
}

@Composable
fun ProgressView(st: TransferState, onStop: () -> Unit, stopLabel: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (st.done) "اكتمل النقل" else "جاري النقل...", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(progress = { st.percent }, modifier = Modifier.size(200.dp), strokeWidth = 14.dp, color = Blue)
            Text("${(st.percent * 100).toInt()}%", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("${fmtSize(st.doneBytes)} / ${fmtSize(st.totalBytes)}", color = Color.White.copy(alpha = 0.8f))
        if (st.currentFile.isNotEmpty() && !st.done) Text(st.currentFile, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1)
        Spacer(Modifier.height(12.dp))
        Text("السرعة: ${String.format(Locale.US, "%.1f", st.speedBps / 1048576.0)} MB/s", color = Color.White)
        Text("الوقت المتبقي: ${fmtTime(st.remainingSec)}", color = Color.White)
        if (st.done && st.fileCount > 0 && (st.verified > 0 || st.mismatched > 0)) {
            Spacer(Modifier.height(8.dp))
            Text(
                if (st.mismatched == 0) "✓ تم التحقق من ${st.verified} ملف بـ SHA-256 (بنفس الجودة)"
                else "⚠ ${st.mismatched} ملف ما تطابقش وتم حذفه",
                color = if (st.mismatched == 0) Color(0xFF4CAF50) else Color(0xFFFFB300)
            )
        } else if (st.done) {
            Spacer(Modifier.height(8.dp))
            Text("✓ تم إرسال الملفات", color = Color(0xFF4CAF50))
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onStop, Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
            Text(if (st.done) "تم" else stopLabel)
        }
    }
}

@Composable
fun SendScreen(files: List<PickedFile>, onDone: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Engine.startSending(ctx.applicationContext, files) }
    DisposableEffect(Unit) { onDispose { Engine.stopSending() } }
    val st by Engine.sendState.collectAsState()
    val qr by Engine.qr.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        when {
            st.error != null -> {
                Spacer(Modifier.height(40.dp))
                Text(st.error ?: "", color = Color(0xFFFFB300), textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onDone) { Text("رجوع") }
            }
            st.active || st.done -> ProgressView(st, onDone, "إيقاف النقل")
            qr == null -> {
                Spacer(Modifier.height(60.dp))
                CircularProgressIndicator(color = Blue)
                Spacer(Modifier.height(16.dp))
                Text("جاري التحضير وحساب SHA-256...", color = Color.White)
                Text("(الملفات الكبيرة تحتاج وقت)", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            else -> {
                val bmp = remember(qr) { qrBitmap(qr!!) }
                Text("في انتظار الاتصال..", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("قم بمسح رمز QR من الجهاز الآخر", color = Color.White.copy(alpha = 0.7f))
                Spacer(Modifier.height(20.dp))
                Image(bmp.asImageBitmap(), null, Modifier.size(260.dp).clip(RoundedCornerShape(20.dp)))
                Spacer(Modifier.height(12.dp))
                Text("الهاتفين لازم يكونوا على نفس الـ Wi-Fi أو Hotspot", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                TextButton(onClick = onDone) { Text("إلغاء") }
            }
        }
        Spacer(Modifier.weight(1f))
        Signature()
    }
}

@Composable
fun ReceiveScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        Engine.resetRecv()
        onDispose { Engine.cancelRecv() }
    }
    val st by Engine.recvState.collectAsState()
    val scanner = rememberLauncherForActivityResult(ScanContract()) { r ->
        val c = r.contents
        if (c != null) Engine.receive(ctx.applicationContext, c)
        else Toast.makeText(ctx, "ما تمش مسح الـ QR", Toast.LENGTH_SHORT).show()
    }
    val launchScan: () -> Unit = {
        scanner.launch(ScanOptions().setPrompt("وجّه الكاميرا نحو رمز QR").setBeepEnabled(false).setOrientationLocked(false))
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchScan() else Toast.makeText(ctx, "لازم تسمح بالتخزين باش نحفظ الملفات", Toast.LENGTH_LONG).show()
    }
    val idle = !st.active && !st.done && st.error == null
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        when {
            st.active || st.done -> ProgressView(st, { if (st.done) onBack() else Engine.cancelRecv() }, "إيقاف النقل")
            else -> {
                Spacer(Modifier.height(40.dp))
                Text("تلقي الملفات", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("افتح «إرسال» في الهاتف الآخر، ثم امسح رمز QR", color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                if (st.error != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(st.error ?: "", color = Color(0xFFFFB300), textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        Engine.resetRecv()
                        if (Build.VERSION.SDK_INT < 29 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                        ) permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else launchScan()
                    },
                    Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)
                ) { Text(if (idle) "مسح QR" else "إعادة المحاولة") }
                TextButton(onClick = onBack) { Text("رجوع") }
            }
        }
        Spacer(Modifier.weight(1f))
        Signature()
    }
}
