FileX Pro  -  By : Adem Hadyaoui

طريقة التشغيل:
1) فك الضغط، وافتح المجلد FileXPro في Android Studio (Hedgehog أو أحدث) عبر Open.
2) انتظر Gradle Sync (يحتاج إنترنت في أول مرة، يحمّل Gradle 8.7 والمكتبات).
   إذا طلب منك JDK اختر JDK 17 (المدمج في Android Studio).
3) شغّل على هاتفين Android 10 أو أحدث (minSdk 24).
4) الهاتف 1: إرسال > اختيار الملفات > إرسال الآن > يظهر QR.
   الهاتف 2: تلقي الملفات > مسح QR.
5) الملفات المستلمة تتحفظ في Download/FileX.

ملاحظات:
- الهاتفين لازم على نفس الـ Wi-Fi أو أحدهما يفعّل Hotspot والآخر يتصل بيه.
- النقل عبر HTTP محلي برمز سري عشوائي (بدون TLS حالياً).
- لا يوجد gradlew في الـ zip؛ Android Studio يتكفل بالأمر.
